#include "scalar_evaluator.h"

using namespace std;


bool ScalarEvaluator::dead_ends_are_reliable() const
{
    return true;
}
