
#ifndef VI_FACTORY_H
#define VI_FACTORY_H

#include "prob_search_engine_factory.h"

namespace prob_search_engine_factory {
    extern Plugin<SearchEngine> avi;
}

#endif
